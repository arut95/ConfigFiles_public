import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { Http } from '@angular/http';
import {servicetest} from './form.service';
import { AppComponent }  from './app.component';
import {formComponent} from './form.component';

@NgModule({
  imports:      [ BrowserModule ],
  //imports:      [ BrowserModule ,Http],
  declarations: [ AppComponent , formComponent],
  bootstrap:    [ AppComponent ],
  providers: [servicetest],
})
export class AppModule { }
