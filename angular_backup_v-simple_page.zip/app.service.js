/*

import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Rx';
import {Http,Response} from '@angular/http';

@Injectable()
export class servicetest{
data:any;
constructor(private http_: Http){
  //this.http_.post("Url","ehyrhj").map((res:Response)=>this.data=res.json);
}

  email:any;
  batch:any;
  expiry:any;
  //
    submit(email,batch,expiry){
        return "yo";
    }
//

}

*/ 
//# sourceMappingURL=app.service.js.map