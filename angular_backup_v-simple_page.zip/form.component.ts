import { Component } from '@angular/core';
import {servicetest} from './form.service';

@Component ({
   selector: 'form',
   templateUrl: './form.component.html',
   providers: [servicetest],
})

export class formComponent{ 
  name = 'Angular';
  res:any;
  submission:any;

constructor(private _service:servicetest){
//_service.postData().subscribe(response=>res);
}

submit(email,batch,expiry){

    //let food = {email: email};
    this.submission=this._service.submit(email,batch,expiry);
}

 }
