import { Component } from '@angular/core';
import { ServiceTest} from './form.service';
import { ReactiveFormsModule, FormGroup, FormControl } from '@angular/forms';

@Component ({
   selector: 'app-form',
   templateUrl: './form.component.html',
   providers: [ ServiceTest ],
})

export class FormComponent {
    form = new FormGroup({
                          mailOption: new FormControl('1'),
                        });

  res: any;
  // submission:any;

  constructor(private _service: ServiceTest) {
        console.log('in form.component constructor');
  }

  submit(email: string, batch: string, expiry: string, mailOption: any, adminUsername: string, adminPassword: string) {
        const token = adminUsername + ':' + adminPassword;
      console.log('Inside submit function. Now, calling service.');
      // this.submission="Result - "+
      return this._service.submit(email, batch, expiry, mailOption, token);
  }

}
