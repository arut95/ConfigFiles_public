# concourse-windows-release

This is a BOSH release for [Concourse](http://concourse.ci/) that enables deploying a Windows worker.
