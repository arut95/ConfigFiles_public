package com.palusers.domain;

public class UserCreateRequest {
	public String employeeEmailId; 
	public String uniqueid;
}
