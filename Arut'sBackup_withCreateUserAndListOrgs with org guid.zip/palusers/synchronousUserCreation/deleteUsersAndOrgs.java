package com.palusers.synchronousUserCreation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.RestController;

import com.palusers.cloudAPI.ManageUsers;
import com.palusers.common.ApplicationConstants;
import com.palusers.services.CloudUserManageService;

@RestController
public class deleteUsersAndOrgs {

	@Autowired
	private ManageUsers manageUsers;
	
	@Autowired
	private CloudUserManageService cloudUsrManageService;

	@Value("${oauthpassword}")
	private String oauthpassword;
	
	@Value("${oauthusername}")
	private String oauthusername;
	
	@Value("${uaalogin}")
	private String uaalogin;
	
	@Value("${fixedDelayDeleteAccountAndOrgInMilliseconds}")
	private String fixedDelayDeleteAccountAndOrgInMilliseconds;
	
	//@RequestMapping(value="creatingByArut/delete")
	@Scheduled(fixedDelayString = "${fixedDelayDeleteAccountAndOrgInMilliseconds}")
	public String delete_UsersAndOrgs() {
		String oAuthtoken = cloudUsrManageService.getAuthtokenforOrgCreation(oauthusername,oauthpassword,ApplicationConstants.OAUTHGRANTTYPE);
		String deletedList=null;
		if(oAuthtoken !=null)
		{
			deletedList = cloudUsrManageService.deleteUsersAndOrgs(oAuthtoken);
			return deletedList;					
		}
		return deletedList;
	}

}
