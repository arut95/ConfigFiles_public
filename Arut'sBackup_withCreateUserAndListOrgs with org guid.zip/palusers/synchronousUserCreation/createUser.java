package com.palusers.synchronousUserCreation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.palusers.common.ApplicationConstants;
import com.palusers.domain.UAAEmailData;
import com.palusers.domain.UAAUserData;
import com.palusers.logger.ILogger;
import com.palusers.logger.LoggerFactory;
import com.palusers.services.CloudUserManageService;

@RestController
public class createUser {

	private String errorinAccCreation="Error has occurred in creating user. Account might exists.";

	private static ILogger logger;	
	
	@Value("${uaalogin}")
	private String uaalogin;

	@Value("${uaacreateuser}")
	private String uaacreateuser;

	
	@Value("${userpasswordlength}")
	private String userpasswordlength;

	@Value("${oauthpassword}")
	private String oauthpassword;
	
	@Value("${oauthusername}")
	private String oauthusername;
	
	@Autowired
	RestTemplate restTemplate; 
	
	@Autowired
	private CloudUserManageService cloudUsrManageService;

	public createUser(LoggerFactory loggerFactory)
	{
		logger = loggerFactory.getLoggerInstance();
	}

	private void logError(String username, String usrMsg, String adminMsg)
	{
		logger.error(adminMsg + username);		
	}

	@CrossOrigin(origins = "http://localhost:3000")
	@RequestMapping(value="hello", method = RequestMethod.GET)
	public String hello() 
    {
		logger.info("yo. it's working");
		return "voila";
    }
	

	@CrossOrigin(origins = "http://localhost:3000")
	@RequestMapping(value="/creatingByArut/{email}/{batch}/{expiry}", method = RequestMethod.GET)
	public String creatingUser(@PathVariable("email") String username,@PathVariable("batch") String batch_tag,@PathVariable("expiry") String expirydate) throws ParseException
	{
		logger.info(" "+username+" "+batch_tag+" "+expirydate);

		String orgName=null;
		String spacename="sandbox";
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	    dateFormat.setLenient(false);
	    try
	    {
	    	Date expirydate_temp = dateFormat.parse(expirydate.trim());
	    	expirydate=new SimpleDateFormat("ddMMyy").format(expirydate_temp);
			logger.info("Expiry Date in required format : "+expirydate);
			
			String token = cloudUsrManageService.getToken(uaalogin);
			logger.info("Getting Token for creating user "+ username);			
			if(token !=null)
			{
				logger.info("Token received for creating users "+ username);					//
				logger.info("Creating user in CF " + username);
				String password = UUID.randomUUID().toString().substring(0, Integer.parseInt(userpasswordlength));
				String newuserId = createUserInCF(token,username,password);					
				if(newuserId !=null)
				{
					logger.info("User created in CF " + username);					    
					logger.info("Getting Token for creating org and association "+ username);
					String oAuthtoken = cloudUsrManageService.getAuthtokenforOrgCreation(oauthusername,oauthpassword,ApplicationConstants.OAUTHGRANTTYPE);
					if(oAuthtoken !=null)
					{
						try
						{
							if(username.indexOf('.')==-1 || username.indexOf('@')==-1)
								throw new Exception("Invalid username");
							else if(username.indexOf('.') > username.indexOf('@'))
								orgName=username.substring(0,username.indexOf('@'));
							else
								orgName=username.substring(0,1)+username.substring(username.indexOf('.')+1,username.indexOf('@'));
							logger.info("Token received for creating org and association "+ username);						
							logger.info("Creating org "+ username);
							orgName=orgName+'-'+batch_tag+'-'+expirydate;
							orgName=orgName.toLowerCase();
							logger.info("Org Name : " + orgName);
							String orgId = cloudUsrManageService.createOrg(oAuthtoken, orgName);
							if(orgId !=null)
							{
								logger.info("orgId : "+orgId);
								logger.info("Associating user "+username+" to org "+ orgName);
								HttpStatus resOrgtoUsr = cloudUsrManageService.associateOrgtoUser(oAuthtoken,username,orgId);
								logger.info("resOrgtoUsr - "+ resOrgtoUsr);
								if(resOrgtoUsr== HttpStatus.CREATED)
								{
									logger.info("User associated to org "+ username);
									String spaceId = cloudUsrManageService.createSpace(oAuthtoken, spacename, orgId);
									if(spaceId !=null)
									{
										logger.info("Space created "+ username);									
										logger.info("Associating user to space "+ username);
										HttpStatus resSpacetoUsr = cloudUsrManageService.associateSpacetoUser(oAuthtoken, username, spaceId);						
		
										if(resSpacetoUsr== HttpStatus.CREATED)
										{
											logger.info("User associated to space "+ username);	
											logger.info("User account created with orgs and spaces.\nUsername: " + username + " at "+ LocalDateTime.now());
											//userservice.updateAccountCreationStatus(username,ApplicationConstants.ActivationStatus.ACTIVATED.name(),Timestamp.valueOf(LocalDateTime.now()));
											//saveAccountEmail(accountcreationemailsubject,"",password,true);
		
											return "Created CF account for "+ username +" with password as "+ password;
										}
										else
										{logError(username,errorinAccCreation,"Error in associating user to space: ");}
									}
									else
									{logError(username,errorinAccCreation,"Error in creating space: ");}
								}
								else
								{logError(username,errorinAccCreation,"Error in associating user to org: ");}
							}
							else
							{logError(username,errorinAccCreation,"Error in creating org and org id is null: ");}
						}
						catch(Exception e)
						{logger.error(e.getMessage());}
					}
					else
					{logError(username,errorinAccCreation,"Oauth token is null: ");}
				}
				else
				{logError(username,errorinAccCreation,"Error in creating user in CF: ");}
			}
	    } 
	    catch (ParseException pe) 
	    {
	      logger.info("Invalid Date");
	    }
		return "There was some error while creating user.";
}


	private String createUserInCF(String token,String username, String password)
	{	 
		UAAUserData uaaUserData = new UAAUserData();
		uaaUserData.externalId= username;
		uaaUserData.userName= username;
		
		UAAEmailData uaaEmail = new UAAEmailData();
		uaaEmail.primary =true;
		uaaEmail.value=username;
		List<UAAEmailData> emailList= new ArrayList<UAAEmailData>();
		emailList.add(uaaEmail);
		uaaUserData.emails = emailList;
		
		uaaUserData.active = true;
		uaaUserData.verified =true;
		uaaUserData.origin="uaa";
		uaaUserData.password= password;
		List<String> lst = Arrays.asList("urn:scim:schemas:core:1.0");
		uaaUserData.schemas =lst;
		
		return cloudUsrManageService.createUser(token, uaaUserData);		
	}
}
