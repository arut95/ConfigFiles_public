package com.palusers.synchronousUserCreation;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.palusers.cloudAPI.ManageUsers;
import com.palusers.common.ApplicationConstants;
import com.palusers.services.CloudUserManageService;

@RestController
public class deleteUsersAndOrgs {

	@Autowired
	private ManageUsers manageUsers;
	
	@Autowired
	private CloudUserManageService cloudUsrManageService;

	@Value("${oauthpassword}")
	private String oauthpassword;
	
	@Value("${oauthusername}")
	private String oauthusername;
	
	@Value("${uaalogin}")
	private String uaalogin;

	@RequestMapping(value="creatingByArut/delete")
	public void listOrgs() {
		String oAuthtoken = cloudUsrManageService.getAuthtokenforOrgCreation(oauthusername,oauthpassword,ApplicationConstants.OAUTHGRANTTYPE);
		if(oAuthtoken !=null)
		{
			String[][] orgs = cloudUsrManageService.listOrgs(oAuthtoken);
			for(int i=0;i<orgs.length;i++)
			{
				if(orgs[i][0].matches(".*-\\d{6}")) // checks if the org name is of the pattern like "orgname-pal-batch6-010118"
				{
					int len=orgs[i][0].length();
					try {
						Date expirydate = new SimpleDateFormat("ddMMyy").parse(orgs[i][0].substring(len-6, len)); //Trimming only the Expiry date and parsing it to date format
						Date currDate = new Date(); //Current date
				        long diffBetweenDates = currDate.getTime() - expirydate.getTime();
				        if(diffBetweenDates > 1209600000) //14*24*60*60*1000 = 1209600000
				        {
				        	//If difference between current date and expiry date is greater than 14 days, Delete the org and user
				        	
				        	System.out.println("Should delete the org and user here");
				        	
				        	String token = cloudUsrManageService.getToken(uaalogin);
				        	if(token != null)
				        	{
				        		//manageUsers.deleteOperations( , orgs[i][1] , userEmailId);
				        	}
				        	
				        }
				        
					} catch (ParseException e) {
						e.printStackTrace();
					} 
					
					
					System.out.println(orgs[i][0]+" - "+orgs[i][1]);
				}
				else
					System.out.println("yo---->"+orgs[i][0]+" - "+orgs[i][1]);
				
			}
				
			
		
		}
	}

}
